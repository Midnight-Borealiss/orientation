# orientation-engine

Moteur d'orientation réutilisable : un quiz guidé qui recommande une filière à partir du profil d'un prospect.

Le moteur ne connaît aucune filière. Il consomme des fiches de données validées contre un schéma. Changer de contexte d'orientation (autre établissement, orientation métier, choix de spécialisation) revient à écrire un nouveau jeu de données — sans toucher au code.

---

## État du projet

| Étape | Statut |
|---|---|
| Schéma de données | fait |
| Extraction des brochures PDF | fait |
| Rapport des manques + export CSV | fait |
| Validation CI | fait |
| Extraction révisée (3 profils, segmentation) | chemin critique |
| Calcul de distinctivité | point de contrôle |
| Moteur de scoring | après le point de contrôle |
| Interface du quiz | à venir |

---

## Structure

```
config/taxonomy.json      Vocabulaire commun : écoles, domaines, axes
config/domaines_axes.json Les 2 axes de disposition, par domaine — à collecter
config/departages.json    Questions de départage par paire + seuils
schema/filiere.schema.json  Contrat de données. Rien n'entre sans le respecter.
data/brochures/<ecole>/   Brochures PDF, rangées par école
data/filieres/            Fiches JSON générées, une par filière
scripts/extract.mjs       PDF → fiches brouillon
scripts/report.mjs        Ce qui manque, et à qui le demander
scripts/distinctivite.mjs Ce qui distingue chaque programme dans son domaine
scripts/validate.mjs      Contrôle schéma + taxonomie
```

Lire `CLAUDE.md` avant toute modification : il contient l'architecture validée,
le principe directeur, et la liste de ce qu'il ne faut pas faire.

## Installation

```bash
npm install
```

Node 18 ou plus.

## Utilisation

**1. Ranger les brochures par école**, en reprenant les identifiants de `config/taxonomy.json` :

```
data/brochures/ism-business/licence-finance-2025.pdf
data/brochures/ism-informatique/master-cybersecurite-2025.pdf
```

**2. Extraire :**

```bash
npm run extract          # toutes les brochures
npm run extract -- --dump   # écrit aussi le texte brut dans data/_raw/ (utile pour ajuster le parsing)
```

Chaque brochure produit une fiche dans `data/filieres/`, au statut `brouillon`.

**3. Voir ce qui manque :**

```bash
npm run report           # à l'écran
npm run report -- --csv  # data/_manques.csv, à envoyer aux équipes
```

Le CSV contient une colonne `destinataire` : filtre dessus et chaque responsable ne reçoit que les 3 ou 4 champs de sa filière, au lieu d'une fiche vierge à remplir.

**4. Valider :**

```bash
npm run validate
```

---

## Le principe de traçabilité

Chaque champ d'une fiche porte sa source dans `meta.sources` :

| Valeur | Signification |
|---|---|
| `brochure` | Extrait du PDF. Fiable, sous réserve de l'année. |
| `inference` | Deviné par le script à partir du champ lexical. **À faire confirmer.** |
| `responsable` | Confirmé par le responsable de programme. |
| `admissions` | Fourni par le service des admissions. |
| `manuel` | Saisi à la main. |

Les notes d'axes et les domaines sortent toujours en `inference` : ce sont des brouillons destinés à être corrigés, pas des vérités. `report.mjs` les traite comme manquants tant qu'un humain ne les a pas validés.

`meta.statut` suit le cycle `brouillon` → `a_valider` → `valide`.

---

## Adapter le parsing à d'autres brochures

Toute la dépendance à la mise en page est concentrée dans `scripts/extract.mjs`, sections `RULES` et `SECTION_TITLES`. Si une brochure titre ses débouchés « Perspectives professionnelles » plutôt que « Débouchés », il suffit d'ajouter le motif :

```js
debouches: /(d[ée]bouch[ée]s|m[ée]tiers\s+vis[ée]s|perspectives\s+professionnelles)/i,
```

Lancer `npm run extract -- --dump` puis lire `data/_raw/*.txt` est la façon la plus rapide de voir comment le PDF est réellement structuré.

---

## Réutiliser pour un autre cas d'orientation

1. Remplacer `config/taxonomy.json` par le vocabulaire du nouveau contexte.
2. Produire les fiches dans `data/filieres/` (extraction ou saisie).
3. `npm run validate`.

Le moteur et l'interface suivent la donnée. Les 5 axes sont volontairement génériques — ils décrivent un profil, pas un secteur — ce qui les rend transposables au-delà de l'enseignement supérieur.

## Limites connues

- L'extraction suppose des PDF texte. Les PDF scannés sont signalés et ignorés (une passe OCR serait nécessaire).
- L'inférence des axes est lexicale, donc grossière : elle sert à donner un point de départ à corriger, pas un résultat.
- Les brochures d'une année passée peuvent contenir des frais, dates ou programmes obsolètes. `meta.annee_source` sert à repérer ce qui doit être revérifié.
