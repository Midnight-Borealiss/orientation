#!/usr/bin/env node
/**
 * extract.mjs — Brochures PDF ---> fiches filière (brouillon)
 *
 *   node scripts/extract.mjs                 # traite data/brochures/*.pdf
 *   node scripts/extract.mjs --file x.pdf    # une seule brochure
 *   node scripts/extract.mjs --dump          # écrit aussi le texte brut (debug parsing)
 *
 * Ce script ne DEVINE jamais en silence. Tout champ non trouvé reste null et
 * apparaît dans le rapport des manques (scripts/report.mjs). Chaque champ trouvé
 * est tracé dans meta.sources.
 */

import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.join(__dirname, "..");
const IN_DIR = path.join(ROOT, "data", "brochures");
const OUT_DIR = path.join(ROOT, "data", "filieres");
const RAW_DIR = path.join(ROOT, "data", "_raw");

const args = process.argv.slice(2);
const ONE = args.includes("--file") ? args[args.indexOf("--file") + 1] : null;
const DUMP = args.includes("--dump");

/* ── Extraction texte via pdfjs ───────────────────────────────── */

async function pdfToText(filePath) {
  const pdfjs = await import("pdfjs-dist/legacy/build/pdf.mjs");
  const data = new Uint8Array(fs.readFileSync(filePath));
  const doc = await pdfjs.getDocument({ data, useSystemFonts: true }).promise;
  const pages = [];
  for (let i = 1; i <= doc.numPages; i++) {
    const page = await doc.getPage(i);
    const content = await page.getTextContent();
    // Regroupe par ligne via la coordonnée Y, sinon les mots arrivent en vrac
    const lines = new Map();
    for (const item of content.items) {
      if (!item.str || !item.str.trim()) continue;
      const y = Math.round(item.transform[5]);
      if (!lines.has(y)) lines.set(y, []);
      lines.get(y).push({ x: item.transform[4], s: item.str });
    }
    const ordered = [...lines.entries()]
      .sort((a, b) => b[0] - a[0])
      .map(([, parts]) =>
        parts.sort((a, b) => a.x - b.x).map((p) => p.s).join(" ").replace(/\s+/g, " ").trim()
      )
      .filter(Boolean);
    pages.push(ordered.join("\n"));
  }
  return pages.join("\n\n");
}

/* ── Règles de parsing ────────────────────────────────────────────
 * À AJUSTER une fois les vraies brochures vues : ce sont les seules
 * lignes du projet qui dépendent de la mise en page ISM.
 * ─────────────────────────────────────────────────────────────── */

const RULES = {
  niveau: [
    { re: /\b(BTS|brevet de technicien)\b/i, val: "bts" },
    { re: /\blicence\s+professionnelle\b/i, val: "licence-pro" },
    { re: /\bMBA\b/i, val: "mba" },
    { re: /\bmaster\b/i, val: "master" },
    { re: /\blicence\b/i, val: "licence" },
    { re: /\bcertificat\b/i, val: "certificat" },
  ],
  langue: [
    { re: /\bbilingue\b/i, val: "bilingue" },
    { re: /\b(enseignement en anglais|taught in english)\b/i, val: "anglais" },
  ],
  niveau_maths: [
    { re: /\b(math[ée]matiques (avanc[ée]es|renforc[ée]es)|forte composante quantitative)\b/i, val: "eleve" },
    { re: /\b(statistiques|math[ée]matiques appliqu[ée]es|analyse quantitative)\b/i, val: "moyen" },
    { re: /\b(notions de math[ée]matiques|math[ée]matiques de base)\b/i, val: "faible" },
  ],
};

// Sections repérées par leur titre. La capture s'arrête au titre suivant.
const SECTION_TITLES = {
  description: /(objectifs?\s+de\s+la\s+formation|pr[ée]sentation|objectifs?\s+p[ée]dagogiques?)/i,
  debouches: /(d[ée]bouch[ée]s|m[ée]tiers\s+vis[ée]s|opportunit[ée]s\s+de\s+carri[èe]re|insertion\s+professionnelle)/i,
  prerequis: /(conditions?\s+d[''’]admission|pr[ée]requis|profil\s+requis|admission)/i,
  programme: /(programme|contenu\s+de\s+la\s+formation|enseignements?|maquette)/i,
};

const ANY_TITLE = new RegExp(
  "^\\s*(" +
    Object.values(SECTION_TITLES).map((r) => r.source).join("|") +
    "|contact|frais|tarifs?|dur[ée]e|t[ée]moignages?)\\s*:?\\s*$",
  "i"
);

function extractSection(text, titleRe) {
  const lines = text.split("\n");
  const start = lines.findIndex((l) => titleRe.test(l) && l.trim().length < 80);
  if (start === -1) return null;
  const out = [];
  for (let i = start + 1; i < lines.length; i++) {
    const l = lines[i];
    if (ANY_TITLE.test(l)) break;
    if (l.trim()) out.push(l.trim());
    if (out.length > 40) break;
  }
  const joined = out.join(" ").replace(/\s+/g, " ").trim();
  return joined.length > 15 ? joined : null;
}

function firstMatch(text, rules) {
  for (const r of rules) if (r.re.test(text)) return r.val;
  return null;
}

function extractDuree(text) {
  const m = text.match(/\b(\d)\s*(?:ans?|ann[ée]es?)\b/i);
  return m ? Number(m[1]) : null;
}

function extractSeriesBac(text) {
  const m = text.match(/\b(?:s[ée]ries?|baccalaur[ée]ats?)\s*:?\s*([A-Z0-9,\s/et-]{2,60})/i);
  if (!m) return [];
  const found = m[1].match(/\b(S[123]|L[12]a?|G|STMG|T[12]|F6)\b/g);
  return found ? [...new Set(found)] : [];
}

function extractMetiers(section) {
  if (!section) return [];
  return section
    .split(/[•·;,]|\s-\s|\u2022/)
    .map((s) => s.trim())
    .filter((s) => s.length > 4 && s.length < 60 && /^[A-ZÀ-Ÿ]/.test(s))
    .slice(0, 6);
}

// Première inférence des axes à partir du champ lexical. C'est un BROUILLON,
// explicitement marqué "inference" : le responsable corrige en un clic.
const LEXIQUE = {
  quantitatif: /\b(financ|comptab|budget|statistiq|calcul|math|analyse chiffr|audit|fiscal|[ée]conom)/gi,
  technique: /\b(technique|logiciel|d[ée]veloppe|code|programm|r[ée]seau|syst[èe]me|machine|maintenance|laboratoire|ing[ée]nier)/gi,
  relationnel: /\b(clien|[ée]quipe|communica|vente|n[ée]gocia|relation|patient|accompagn|conseil|management|ressources humaines)/gi,
  creatif: /\b(cr[ée]ati|design|graphi|r[ée]dac|contenu|innovation|marketing|publicit|audiovisuel|artistiq)/gi,
  rigueur: /\b(norme|proc[ée]dur|r[ée]glementa|conformit|qualit[ée]|s[ée]curit|contr[ôo]le|juridiq|protocol|certifica)/gi,
};

function inferAxes(text) {
  const counts = {};
  for (const [axe, re] of Object.entries(LEXIQUE)) {
    counts[axe] = (text.match(re) || []).length;
  }
  const max = Math.max(...Object.values(counts), 1);
  const axes = {};
  for (const [axe, n] of Object.entries(counts)) {
    // normalise sur 1..5, jamais 0
    axes[axe] = Math.max(1, Math.min(5, Math.round((n / max) * 4) + 1));
  }
  return axes;
}

function inferDomaines(text, taxonomy) {
  const hits = [];
  const map = {
    finance: /\bfinanc|banqu|assuranc|bours|investis/gi,
    comptabilite: /\bcomptab|audit|fiscal|expertise comptable/gi,
    gestion: /\bgestion|administrat|pilotage|contr[ôo]le de gestion/gi,
    entrepreneuriat: /\bentrepreneur|cr[ée]ation d[''’]entreprise|startup/gi,
    marketing: /\bmarketing|vente|commercial|distribution/gi,
    communication: /\bcommunication|m[ée]dia|journalis|relations publiques/gi,
    design: /\bdesign|graphi|infographi|audiovisuel/gi,
    informatique: /\bd[ée]veloppement|logiciel|programmation|informatique de gestion|web/gi,
    reseaux: /\br[ée]seaux|t[ée]l[ée]communication|syst[èe]mes et r[ée]seaux|administration syst/gi,
    cybersecurite: /\bcybers[ée]curit|s[ée]curit[ée] informatique|s[ée]curit[ée] des syst/gi,
    data: /\bdata|donn[ée]es|intelligence artificielle|big data|business intelligence/gi,
    ingenierie: /\bing[ée]nierie|m[ée]canique|[ée]lectrotechniq|industriel|automatisme/gi,
    btp: /\bbtp|g[ée]nie civil|b[âa]timent|travaux publics|architecture/gi,
    energie: /\b[ée]nergie|renouvelable|environnement|solaire/gi,
    logistique: /\blogistiq|transport|supply chain|cha[îi]ne d[''’]approvisionnement/gi,
    rh: /\bressources humaines|\brh\b|recrutement|gestion du personnel|paie/gi,
    droit: /\bdroit|juridiq|l[ée]gislation|contentieux/gi,
    sante: /\bsant[ée]|infirmi|soins|m[ée]dical|pharmac|biologie m[ée]dicale/gi,
    tourisme: /\btourisme|h[ôo]tellerie|restauration|[ée]v[ée]nementiel/gi,
    langues: /\blangues|traduction|interpr[ée]tariat|international business/gi,
  };
  for (const [id, re] of Object.entries(map)) {
    const n = (text.match(re) || []).length;
    if (n >= 2) hits.push({ id, n });
  }
  return hits.sort((a, b) => b.n - a.n).slice(0, 3).map((h) => h.id);
}

/* ── Construction de la fiche ─────────────────────────────────── */

const slug = (s) =>
  s.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 60);

function buildFiche(text, fileName) {
  const sources = {};
  const mark = (field, src, val) => {
    if (val !== null && val !== undefined && !(Array.isArray(val) && !val.length)) {
      sources[field] = src;
      return val;
    }
    return Array.isArray(val) ? [] : null;
  };

  const titre = text.split("\n").map((l) => l.trim())
    .find((l) => l.length > 8 && l.length < 90 && !/^\d/.test(l)) || path.basename(fileName, ".pdf");

  const secDebouches = extractSection(text, SECTION_TITLES.debouches);
  const secDescription = extractSection(text, SECTION_TITLES.description);
  const secPrerequis = extractSection(text, SECTION_TITLES.prerequis);

  const fiche = {
    id: slug(titre),
    nom: mark("nom", "brochure", titre),
    ecole: null,
    niveau: mark("niveau", "brochure", firstMatch(text, RULES.niveau)),
    duree_annees: mark("duree_annees", "brochure", extractDuree(text)),
    langue: mark("langue", "brochure", firstMatch(text, RULES.langue)) || "francais",

    eligibilite: {
      series_bac: mark("eligibilite.series_bac", "brochure", extractSeriesBac(secPrerequis || text)),
      niveau_maths: mark("eligibilite.niveau_maths", "inference", firstMatch(text, RULES.niveau_maths)),
      prerequis_autres: [],
    },

    axes: inferAxes(text),
    domaines: inferDomaines(text, null),

    profil_ideal: [],
    deconseille_si: [],
    voisines: [],

    debouches: {
      metiers: mark("debouches.metiers", "brochure", extractMetiers(secDebouches)),
      secteurs: [],
      poursuite_etudes: [],
    },

    vitrine: {
      accroche: null,
      description: mark("vitrine.description", "brochure", secDescription ? secDescription.slice(0, 600) : null),
      fait_marquant: null,
      couleur: null,
    },

    meta: {
      sources: { ...sources, axes: "inference", domaines: "inference" },
      statut: "brouillon",
      brochure_fichier: path.basename(fileName),
      annee_source: Number((fileName.match(/20\d{2}/) || [])[0]) || null,
    },
  };

  // Nettoie les null dans les sous-objets pour rester conforme au schéma
  if (!fiche.eligibilite.niveau_maths) delete fiche.eligibilite.niveau_maths;
  if (!fiche.duree_annees) delete fiche.duree_annees;
  if (!fiche.niveau) fiche.niveau = "licence";
  if (!fiche.vitrine.description) delete fiche.vitrine.description;
  if (!fiche.vitrine.accroche) delete fiche.vitrine.accroche;
  if (!fiche.vitrine.fait_marquant) delete fiche.vitrine.fait_marquant;
  if (!fiche.vitrine.couleur) delete fiche.vitrine.couleur;
  if (!fiche.meta.annee_source) delete fiche.meta.annee_source;
  if (!fiche.domaines.length) fiche.domaines = ["gestion"];

  return fiche;
}

/* ── Main ─────────────────────────────────────────────────────── */

async function main() {
  fs.mkdirSync(OUT_DIR, { recursive: true });
  if (DUMP) fs.mkdirSync(RAW_DIR, { recursive: true });

  if (!fs.existsSync(IN_DIR)) {
    console.error(`Dossier introuvable : ${IN_DIR}\nDépose tes brochures PDF dedans.`);
    process.exit(1);
  }

  // Les brochures peuvent être rangées par école :
  //   data/brochures/ism-informatique/master-cyber.pdf  → ecole = "ism-informatique"
  const walk = (dir) =>
    fs.readdirSync(dir, { withFileTypes: true }).flatMap((e) => {
      const p = path.join(dir, e.name);
      if (e.isDirectory()) return walk(p);
      return e.name.toLowerCase().endsWith(".pdf") ? [p] : [];
    });

  const files = ONE
    ? [path.isAbsolute(ONE) ? ONE : path.join(IN_DIR, ONE)]
    : walk(IN_DIR);

  if (!files.length) {
    console.error("Aucun PDF trouvé dans data/brochures/");
    process.exit(1);
  }

  console.log(`\n${files.length} brochure(s) à traiter\n`);
  let ok = 0;

  for (const file of files) {
    const name = path.basename(file);
    try {
      const text = await pdfToText(file);
      if (DUMP) fs.writeFileSync(path.join(RAW_DIR, name.replace(/\.pdf$/i, ".txt")), text);

      if (text.trim().length < 200) {
        console.log(`  ⚠  ${name} — presque aucun texte (PDF scanné ?), à traiter à la main`);
        continue;
      }

      const fiche = buildFiche(text, file);

      const dossier = path.basename(path.dirname(file));
      if (dossier !== "brochures") {
        fiche.ecole = dossier;
        fiche.meta.sources.ecole = "manuel";
      }

      const out = path.join(OUT_DIR, `${fiche.id}.json`);
      fs.writeFileSync(out, JSON.stringify(fiche, null, 2) + "\n");

      const trouves = Object.keys(fiche.meta.sources).length;
      console.log(`  ✓  ${name}\n       → ${fiche.id}.json  (${trouves} champs extraits, ${fiche.domaines.join(", ")})`);
      ok++;
    } catch (err) {
      console.log(`  ✗  ${name} — ${err.message}`);
    }
  }

  console.log(`\n${ok}/${files.length} fiches générées dans data/filieres/`);
  console.log(`Étape suivante :  node scripts/report.mjs\n`);
}

main();
